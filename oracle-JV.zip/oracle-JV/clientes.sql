-- Script SQL para la base de datos Oracle de clientes

CREATE TABLE clientes (
    cliente_id NUMBER PRIMARY KEY,
    correo_electronico VARCHAR2(100) NOT NULL,
    nombre_completo VARCHAR2(200) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE SEQUENCE seq_cliente_id
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;


CREATE OR REPLACE TRIGGER trg_cliente_id
BEFORE INSERT ON clientes
FOR EACH ROW
BEGIN
    IF :NEW.cliente_id IS NULL THEN
        SELECT seq_cliente_id.NEXTVAL INTO :NEW.cliente_id FROM dual;
    END IF;
END;
/


INSERT INTO clientes (correo_electronico, nombre_completo) VALUES ('juan.perez@ejemplo.com', 'Juan Pérez');
INSERT INTO clientes (correo_electronico, nombre_completo) VALUES ('maria.lopez@ejemplo.com', 'María López');
INSERT INTO clientes (correo_electronico, nombre_completo) VALUES ('carlos.rodriguez@ejemplo.com', 'Carlos Rodríguez');


COMMIT;
