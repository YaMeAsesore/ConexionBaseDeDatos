package com.aplicacion;

import com.dao.ClienteDAO;
import com.modelo.Cliente;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;


public class AplicacionClientes {
    private static ClienteDAO clienteDAO;
    private static Scanner scanner = new Scanner(System.in);

    /**
     * Método principal de la aplicación
     * @param args Argumentos de línea de comandos
     */
    public static void main(String[] args) {
        try {

            clienteDAO = new ClienteDAO();
            
            boolean continuar = true;
            while (continuar) {
                mostrarMenu();
                int opcion = obtenerOpcion();
                
                switch (opcion) {
                    case 1:
                        listarClientes();
                        break;
                    case 2:
                        buscarCliente();
                        break;
                    case 3:
                        agregarCliente();
                        break;
                    case 4:
                        actualizarCliente();
                        break;
                    case 5:
                        eliminarCliente();
                        break;
                    case 0:
                        continuar = false;
                        System.out.println("Saliendo de la aplicación...");
                        break;
                    default:
                        System.out.println("Opción no válida. Intente nuevamente.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error de base de datos: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (clienteDAO != null) {
                clienteDAO.cerrar();
            }
            scanner.close();
        }
    }
    

    private static void mostrarMenu() {
        System.out.println("\n===== GESTIÓN DE CLIENTES =====");
        System.out.println("1. Listar todos los clientes");
        System.out.println("2. Buscar cliente por ID");
        System.out.println("3. Agregar nuevo cliente");
        System.out.println("4. Actualizar cliente existente");
        System.out.println("5. Eliminar cliente");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }
    

    private static int obtenerOpcion() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    

    private static void listarClientes() throws SQLException {
        List<Cliente> clientes = clienteDAO.listarTodos();
        
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados.");
            return;
        }
        
        System.out.println("\n===== LISTA DE CLIENTES =====");
        for (Cliente cliente : clientes) {
            System.out.println(cliente);
        }
    }
    

    private static void buscarCliente() throws SQLException {
        System.out.print("Ingrese el ID del cliente: ");
        try {
            long id = Long.parseLong(scanner.nextLine());
            Cliente cliente = clienteDAO.buscarPorId(id);
            
            if (cliente != null) {
                System.out.println("\nCliente encontrado:");
                System.out.println(cliente);
            } else {
                System.out.println("Cliente no encontrado.");
            }
        } catch (NumberFormatException e) {
            System.out.println("ID inválido. Debe ser un número.");
        }
    }
    

    private static void agregarCliente() throws SQLException {
        System.out.println("\n===== AGREGAR NUEVO CLIENTE =====");
        
        System.out.print("ID del cliente: ");
        long id;
        try {
            id = Long.parseLong(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("ID inválido. Debe ser un número.");
            return;
        }
        
        System.out.print("Correo electrónico: ");
        String correo = scanner.nextLine();
        
        System.out.print("Nombre completo: ");
        String nombre = scanner.nextLine();
        
        try {
            Cliente nuevoCliente = new Cliente(id, correo, nombre);
            boolean resultado = clienteDAO.agregar(nuevoCliente);
            
            if (resultado) {
                System.out.println("Cliente agregado correctamente.");
            } else {
                System.out.println("No se pudo agregar el cliente.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    

    private static void actualizarCliente() throws SQLException {
        System.out.println("\n===== ACTUALIZAR CLIENTE =====");
        
        System.out.print("ID del cliente a actualizar: ");
        long id;
        try {
            id = Long.parseLong(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("ID inválido. Debe ser un número.");
            return;
        }
        
        Cliente clienteExistente = clienteDAO.buscarPorId(id);
        if (clienteExistente == null) {
            System.out.println("Cliente no encontrado.");
            return;
        }
        
        System.out.println("Cliente actual: " + clienteExistente);
        
        System.out.print("Nuevo correo electrónico (deje en blanco para mantener el actual): ");
        String correo = scanner.nextLine();
        if (correo.isEmpty()) {
            correo = clienteExistente.correoElectronico();
        }
        
        System.out.print("Nuevo nombre completo (deje en blanco para mantener el actual): ");
        String nombre = scanner.nextLine();
        if (nombre.isEmpty()) {
            nombre = clienteExistente.nombreCompleto();
        }
        
        try {
            Cliente clienteActualizado = new Cliente(id, correo, nombre);
            boolean resultado = clienteDAO.actualizar(clienteActualizado);
            
            if (resultado) {
                System.out.println("Cliente actualizado correctamente.");
            } else {
                System.out.println("No se pudo actualizar el cliente.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    

    private static void eliminarCliente() throws SQLException {
        System.out.println("\n===== ELIMINAR CLIENTE =====");
        
        System.out.print("ID del cliente a eliminar: ");
        try {
            long id = Long.parseLong(scanner.nextLine());
            
            System.out.print("¿Está seguro de eliminar este cliente? (S/N): ");
            String confirmacion = scanner.nextLine();
            
            if (confirmacion.equalsIgnoreCase("S")) {
                boolean resultado = clienteDAO.eliminar(id);
                
                if (resultado) {
                    System.out.println("Cliente eliminado correctamente.");
                } else {
                    System.out.println("No se pudo eliminar el cliente. Verifique que exista.");
                }
            } else {
                System.out.println("Operación cancelada.");
            }
        } catch (NumberFormatException e) {
            System.out.println("ID inválido. Debe ser un número.");
        }
    }
}
