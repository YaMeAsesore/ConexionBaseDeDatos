package com.dao;

import com.database.ConexionOracle;
import com.modelo.Cliente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ClienteDAO {
    private Connection conexion;

    public ClienteDAO() throws SQLException {
        this.conexion = ConexionOracle.obtenerConexion();
    }


    public boolean agregar(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO clientes (cliente_id, correo_electronico, nombre_completo) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setLong(1, cliente.clienteId());
            stmt.setString(2, cliente.correoElectronico());
            stmt.setString(3, cliente.nombreCompleto());
            return stmt.executeUpdate() > 0;
        }
    }


    public Cliente buscarPorId(Long clienteId) throws SQLException {
        String sql = "SELECT * FROM clientes WHERE cliente_id = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setLong(1, clienteId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Cliente(
                        rs.getLong("cliente_id"),
                        rs.getString("correo_electronico"),
                        rs.getString("nombre_completo")
                );
            }
        }
        return null;
    }


    public List<Cliente> listarTodos() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM clientes ORDER BY cliente_id";
        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                clientes.add(new Cliente(
                        rs.getLong("cliente_id"),
                        rs.getString("correo_electronico"),
                        rs.getString("nombre_completo")
                ));
            }
        }
        return clientes;
    }


    public boolean actualizar(Cliente cliente) throws SQLException {
        String sql = "UPDATE clientes SET correo_electronico = ?, nombre_completo = ? WHERE cliente_id = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, cliente.correoElectronico());
            stmt.setString(2, cliente.nombreCompleto());
            stmt.setLong(3, cliente.clienteId());
            return stmt.executeUpdate() > 0;
        }
    }


    public boolean eliminar(Long clienteId) throws SQLException {
        String sql = "DELETE FROM clientes WHERE cliente_id = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setLong(1, clienteId);
            return stmt.executeUpdate() > 0;
        }
    }

    public void cerrar() {
        ConexionOracle.cerrarConexion(conexion);
    }
}
