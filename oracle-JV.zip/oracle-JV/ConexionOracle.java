package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionOracle {

    private static final String URL_CONEXION = "jdbc:oracle:thin:@//172.17.0.2:1521/XE";
    private static final String USUARIO = "admin_sistema";
    private static final String CLAVE = "oracle2025";
    

    static {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            System.err.println("Error al cargar el driver de Oracle: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static Connection obtenerConexion() throws SQLException {
        return DriverManager.getConnection(URL_CONEXION, USUARIO, CLAVE);
    }
    
    public static void cerrarConexion(Connection conexion) {
        if (conexion != null) {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
