package com.modelo;


public record Cliente(
    Long clienteId,
    String correoElectronico,
    String nombreCompleto
) {

    public Cliente {

        if (clienteId == null || clienteId <= 0) {
            throw new IllegalArgumentException("El ID del cliente debe ser un número positivo");
        }
        
        if (correoElectronico == null || correoElectronico.isEmpty()) {
            throw new IllegalArgumentException("El correo electrónico no puede estar vacío");
        }
        
        if (nombreCompleto == null || nombreCompleto.isEmpty()) {
            throw new IllegalArgumentException("El nombre completo no puede estar vacío");
        }
    }
    
    @Override
    public String toString() {
        return "Cliente{" +
                "id=" + clienteId +
                ", correo='" + correoElectronico + '\'' +
                ", nombre='" + nombreCompleto + '\'' +
                '}';
    }
}
