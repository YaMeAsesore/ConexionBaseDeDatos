-- Script SQL para la base de datos de evaluación docente
-- Nombre: evaluacion.sql

-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS evaluacion;

-- Usar la base de datos
USE evaluacion;

-- Tabla para almacenar las respuestas de evaluación
CREATE TABLE IF NOT EXISTS respuestas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    docente VARCHAR(100) NOT NULL COMMENT 'Nombre del profesor evaluado',
    pregunta1 TINYINT NOT NULL COMMENT 'Claridad en explicación (1-4)',
    pregunta2 TINYINT NOT NULL COMMENT 'Fomento de participación (1-4)',
    pregunta3 TINYINT NOT NULL COMMENT 'Puntualidad y responsabilidad (1-4)',
    comentarios TEXT COMMENT 'Observaciones adicionales del estudiante',
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha de registro'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertar algunos datos de ejemplo (opcional)
INSERT INTO respuestas (docente, pregunta1, pregunta2, pregunta3, comentarios) VALUES
('Carlos Martínez', 4, 3, 4, 'Excelente profesor, explica con mucha claridad.'),
('Ana Rodríguez', 3, 4, 3, 'Fomenta mucho la participación en clase.'),
('Luis Hernández', 4, 4, 4, 'Uno de los mejores profesores del departamento.');
