<!-- Footer -->
<footer class="text-center py-3 mt-auto">
    <p class="mb-0">© 2025 ITVO. Sin derechos reservados.</p>
    <p class="mb-0">Contacto: ambrosio.cj@voaxaca.tecnm.mx</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
