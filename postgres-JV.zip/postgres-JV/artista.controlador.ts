import { ArtistaService } from '../servicios/artista.servicio.ts';
import { HttpRespuesta } from "../utilidades/http_respuesta.ts";

export const ArtistaControlador = {
    obtenerTodos: async () => {
        try {
            const artistas = await ArtistaService.obtenerTodos();
            return HttpRespuesta.ok(artistas, "Artistas recuperados correctamente");
        } catch (error) {
            return HttpRespuesta.error("Error al recuperar los artistas");
        }
    },
    
    obtenerPorId: async (id: number) => {
        try {
            const artista = await ArtistaService.obtenerPorId(id);
            if (!artista) {
                return HttpRespuesta.noEncontrado("Artista no encontrado");
            }
            return HttpRespuesta.ok([artista], "Artista encontrado");
        } catch (error) {
            return HttpRespuesta.error("Error al recuperar el artista");
        }
    },
    
    agregar: async (datos: { nombre: string; apellido: string }) => {
        try {
            const nuevoArtista = await ArtistaService.agregar(datos.nombre, datos.apellido);
            return HttpRespuesta.creado(nuevoArtista, "Artista creado correctamente");
        } catch (error) {
            return HttpRespuesta.error("Error al crear el artista");
        }
    },
    
    actualizar: async (id: number, datos: { nombre?: string; apellido?: string }) => {
        try {
            const artistaActualizado = await ArtistaService.actualizar(id, datos);
            if (!artistaActualizado) {
                return HttpRespuesta.noEncontrado("Artista no encontrado");
            }
            return HttpRespuesta.ok([artistaActualizado], "Artista actualizado correctamente");
        } catch (error) {
            return HttpRespuesta.error("Error al actualizar el artista");
        }
    },
    
    eliminar: async (id: number) => {
        try {
            const eliminado = await ArtistaService.eliminar(id);
            if (!eliminado) {
                return HttpRespuesta.noEncontrado("Artista no encontrado");
            }
            return HttpRespuesta.ok([], "Artista eliminado correctamente");
        } catch (error) {
            return HttpRespuesta.error("Error al eliminar el artista");
        }
    }
};
