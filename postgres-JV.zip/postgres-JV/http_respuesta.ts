
export class HttpRespuesta {
    static ok(datos: any[], mensaje: string) {
        return {
            codigo: 200,
            exito: true,
            mensaje,
            datos
        };
    }
    
    static creado(datos: any, mensaje: string) {
        return {
            codigo: 201,
            exito: true,
            mensaje,
            datos: [datos]
        };
    }
    
    static error(mensaje: string) {
        return {
            codigo: 500,
            exito: false,
            mensaje,
            datos: []
        };
    }
    
    static noEncontrado(mensaje: string) {
        return {
            codigo: 404,
            exito: false,
            mensaje,
            datos: []
        };
    }
    
    static solicitudIncorrecta(mensaje: string) {
        return {
            codigo: 400,
            exito: false,
            mensaje,
            datos: []
        };
    }
}
