
import express from 'express';
import { ArtistaControlador } from './artista.controlador.ts';
import { PeliculaControlador } from './pelicula.controlador.ts';


const app = express();
const puerto = 3000;


app.use(express.json());


app.get('/api/artistas', async (req, res) => {
    const respuesta = await ArtistaControlador.obtenerTodos();
    res.status(respuesta.codigo).json(respuesta);
});

app.get('/api/artistas/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    const respuesta = await ArtistaControlador.obtenerPorId(id);
    res.status(respuesta.codigo).json(respuesta);
});

app.post('/api/artistas', async (req, res) => {
    const respuesta = await ArtistaControlador.agregar(req.body);
    res.status(respuesta.codigo).json(respuesta);
});

app.put('/api/artistas/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    const respuesta = await ArtistaControlador.actualizar(id, req.body);
    res.status(respuesta.codigo).json(respuesta);
});

app.delete('/api/artistas/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    const respuesta = await ArtistaControlador.eliminar(id);
    res.status(respuesta.codigo).json(respuesta);
});


app.listen(puerto, () => {
    console.log(`Servidor iniciado en http://localhost:${puerto}`);
});
