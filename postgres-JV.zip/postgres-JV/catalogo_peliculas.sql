-- Script SQL para la base de datos PostgreSQL de películas y artistas


CREATE DATABASE catalogo_peliculas;


\c catalogo_peliculas;


CREATE TABLE IF NOT EXISTS artista (
    artista_id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS pelicula (
    pelicula_id SERIAL PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    duracion_alquiler INTEGER DEFAULT 3,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS pelicula_artista (
    pelicula_id INTEGER REFERENCES pelicula(pelicula_id),
    artista_id INTEGER REFERENCES artista(artista_id),
    rol VARCHAR(50) NOT NULL,
    PRIMARY KEY (pelicula_id, artista_id, rol)
);


INSERT INTO artista (nombre, apellido) VALUES 
('Roberto', 'García'),
('Laura', 'Martínez'),
('Miguel', 'Sánchez');


INSERT INTO pelicula (titulo, duracion_alquiler) VALUES 
('El Misterio del Bosque', 5),
('Aventuras en la Ciudad', 3),
('El Último Viaje', 4);


INSERT INTO pelicula_artista (pelicula_id, artista_id, rol) VALUES 
(1, 1, 'Protagonista'),
(1, 2, 'Secundario'),
(2, 2, 'Protagonista'),
(3, 3, 'Protagonista'),
(3, 1, 'Secundario');
