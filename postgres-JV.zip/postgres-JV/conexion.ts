import { Pool } from "pg";
const configuracion = {
    host: 'localhost',
    usuario: 'postgres',
    clave: '240416',
    baseDatos: 'catalogo_peliculas',
    puerto: 5432,
};


const pool = new Pool({
    host: configuracion.host,
    user: configuracion.usuario,
    password: configuracion.clave,
    database: configuracion.baseDatos,
    port: configuracion.puerto,
});


export const baseDatos = drizzle(pool, { schema: esquema });


export const cerrarConexiones = async () => {
    try {
        await pool.end();
        console.log('Conexiones cerradas correctamente');
    } catch (error) {
        console.error('Error al cerrar conexiones:', error);
    }
};


