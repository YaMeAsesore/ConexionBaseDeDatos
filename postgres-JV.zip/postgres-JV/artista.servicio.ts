import { baseDatos } from './conexion.ts';
import { artista } from './esquema.ts';
import { eq } from 'drizzle-orm';

export const ArtistaService = {
    obtenerTodos: async () => {
        try {
            return await baseDatos.select().from(artista).orderBy(artista.artista_id);
        } catch (error) {
            console.error('Error al obtener artistas:', error);
            throw error;
        }
    },
    
    obtenerPorId: async (id: number) => {
        try {
            const resultado = await baseDatos.select()
                .from(artista)
                .where(eq(artista.artista_id, id));
            
            return resultado.length > 0 ? resultado[0] : null;
        } catch (error) {
            console.error(`Error al obtener artista con ID ${id}:`, error);
            throw error;
        }
    },
    
    agregar: async (nombre: string, apellido: string) => {
        try {
            const resultado = await baseDatos.insert(artista)
                .values({ nombre, apellido })
                .returning();
            
            return resultado[0];
        } catch (error) {
            console.error('Error al agregar artista:', error);
            throw error;
        }
    },
    
    actualizar: async (id: number, datos: { nombre?: string; apellido?: string }) => {
        try {
            // Verificar si el artista existe
            const artistaExistente = await ArtistaService.obtenerPorId(id);
            if (!artistaExistente) {
                return null;
            }
            
            // Actualizar solo los campos proporcionados
            const resultado = await baseDatos.update(artista)
                .set(datos)
                .where(eq(artista.artista_id, id))
                .returning();
            
            return resultado[0];
        } catch (error) {
            console.error(`Error al actualizar artista con ID ${id}:`, error);
            throw error;
        }
    },
    
    eliminar: async (id: number) => {
        try {
            // Verificar si el artista existe
            const artistaExistente = await ArtistaService.obtenerPorId(id);
            if (!artistaExistente) {
                return false;
            }
            
            // Eliminar el artista
            await baseDatos.delete(artista)
                .where(eq(artista.artista_id, id));
            
            return true;
        } catch (error) {
            console.error(`Error al eliminar artista con ID ${id}:`, error);
            throw error;
        }
    }
};
