
import { pgTable, serial, varchar, integer } from 'drizzle-orm/pg-core';


export const artista = pgTable('artista', {
    artista_id: serial('artista_id').primaryKey(),
    nombre: varchar('nombre', { length: 50 }).notNull(),
    apellido: varchar('apellido', { length: 50 }).notNull()
});


export const pelicula = pgTable('pelicula', {
    pelicula_id: serial('pelicula_id').primaryKey(),
    titulo: varchar('titulo', { length: 255 }).notNull(),
    duracion_alquiler: integer('duracion_alquiler').default(3)
});
